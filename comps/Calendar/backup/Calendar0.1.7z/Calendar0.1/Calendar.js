;void function(){
    var _path = script_path_f();
    document.write( '<script src="'+_path+'JC.Calendar.js" ><\/script>' );
    document.write( '<script src="'+_path+'JC.Calendar.pickWeek.js" ><\/script>' );
    document.write( '<script src="'+_path+'JC.Calendar.pickMonth.js" ><\/script>' );
    document.write( '<script src="'+_path+'JC.Calendar.pickSeason.js" ><\/script>' );
}();
